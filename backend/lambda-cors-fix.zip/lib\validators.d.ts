export declare const PROJECT_TYPES: readonly ["Proyecto", "Evolutivo"];
export type ProjectType = typeof PROJECT_TYPES[number];
export declare const PROJECT_PRIORITIES: readonly ["muy-alta", "alta", "media", "baja", "muy-baja"];
export type ProjectPriority = typeof PROJECT_PRIORITIES[number];
export declare const PROJECT_STATUSES: readonly ["Idea", "Conceptualización", "Diseño Detallado", "Viabilidad Técnico-Económica", "Construcción y Pruebas / Desarrollo", "Implantación", "Finalizado"];
export type ProjectStatus = typeof PROJECT_STATUSES[number];
export declare const SKILLS: readonly ["PM", "Conceptualización", "Análisis", "Construcción", "QA", "General", "Diseño", "Project Management"];
export type SkillName = typeof SKILLS[number];
export declare const DOMAINS: readonly ["Atención", "Facturación y Cobros", "Integración", "Datos", "Ventas | Contratación y SW", "Operación de Sistemas y Ciberseguridad"];
export type DomainName = typeof DOMAINS[number];
export declare const PROFICIENCY_LEVELS: readonly ["junior", "mid", "senior"];
export type ProficiencyLevel = typeof PROFICIENCY_LEVELS[number];
export declare const DEFAULT_CAPACITY_HOURS = 160;
export interface ProjectData {
    code: string;
    title: string;
    description?: string;
    type: string;
    priority: string;
    startDate?: Date | string;
    endDate?: Date | string;
    statusId?: string;
    domainId?: string;
}
export interface ResourceData {
    code: string;
    name: string;
    email?: string;
    defaultCapacity?: number;
    active?: boolean;
}
export interface AssignmentData {
    projectId: string;
    resourceId: string;
    skillId: string;
    month: number;
    year: number;
    hours: number;
}
export interface CapacityData {
    resourceId: string;
    month: number;
    year: number;
    totalHours: number;
}
export declare const validateProjectData: (data: Partial<ProjectData>) => void;
export declare const validateResourceData: (data: Partial<ResourceData>) => void;
export declare const validateAssignmentData: (data: Partial<AssignmentData>) => void;
export declare const validateCapacityData: (data: Partial<CapacityData>) => void;
export declare const validateUUID: (uuid: string, fieldName: string) => void;
export declare const validatePaginationParams: (page?: string | number, limit?: string | number) => {
    page: number;
    limit: number;
};
//# sourceMappingURL=validators.d.ts.map